# CarRecognition

## Due to Price and Cost, I've deprecated the API. The project will return 404 result when GET/POST requests are made. 


This is one of the best vehicle recognition applications. It can determine the car's license plate number, color, model, brand and year.
      
<img src="screenshots/Screenshot_20190109-002106.png" alt="alt text" width="288" height="512">      <img src="screenshots/1.jpg?raw=true" alt="alt text" width="288" height="512">      <img src="screenshots/2.jpg?raw=true" alt="alt text" width="288" height="512">

<p align="center"><img src="screenshots/3.jpg" alt="alt text" width="288" height="512">      <img src="screenshots/4.jpg" alt="alt text" width="288" height="512"> </p>


