package uz.shukurov.carrecognition.other;

public class RequestCode {

    public static final int MY_PERMISSIONS_REQUEST_EXTERNAL_STORAGE = 999;
    public static final int REQUEST_TAKE_PHOTO = 998;
    public static final int GALLERY_REQUEST = 997;


}
